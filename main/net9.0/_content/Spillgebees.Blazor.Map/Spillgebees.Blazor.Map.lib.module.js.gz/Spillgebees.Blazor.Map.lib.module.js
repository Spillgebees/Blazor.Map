<Project Sdk="Microsoft.VisualStudio.JavaScript.Sdk/1.0.4338480">
  <PropertyGroup>
    <DebugAssetsDirectory>dist\</DebugAssetsDirectory>
    <StaticWebAssetSourceId>Spillgebees.Blazor.Map</StaticWebAssetSourceId>
    <IsPackable>false</IsPackable>
    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
  </PropertyGroup>

  <PropertyGroup Condition="'$(Configuration)'=='Debug'">
    <BuildCommand>npm run build:dev</BuildCommand>
  </PropertyGroup>

  <PropertyGroup Condition="'$(Configuration)'=='Release'">
    <BuildCommand>npm run build:prod</BuildCommand>
  </PropertyGroup>

  <Target Name="Pack" />
  <Target Name="_GetRequiredWorkloads" />
</Project>
